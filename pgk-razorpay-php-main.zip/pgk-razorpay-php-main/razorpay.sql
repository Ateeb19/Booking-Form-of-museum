-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2023 at 02:20 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razorpay`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_details`
--

CREATE TABLE `booking_details` (
  `id` int(255) NOT NULL,
  `options` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `Indian_foreign` varchar(20) NOT NULL,
  `Infant_ticket` int(20) NOT NULL,
  `kids_ticket` int(20) NOT NULL,
  `above12_ticket` int(20) NOT NULL,
  `water_infant_ticket` int(20) NOT NULL,
  `water_kids_ticket` int(20) NOT NULL,
  `water_above12_ticket` int(20) NOT NULL,
  `total_price` varchar(10000) NOT NULL,
  `waterticket` varchar(20) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `Infant_ticket_price` int(12) NOT NULL,
  `kids_ticket_price` int(12) NOT NULL,
  `above12_ticket_price` int(12) NOT NULL,
  `water_infant_ticket_price` int(12) NOT NULL,
  `water_kids_ticket_price` int(12) NOT NULL,
  `water_above12_ticket_price` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking_details`
--

INSERT INTO `booking_details` (`id`, `options`, `date`, `Indian_foreign`, `Infant_ticket`, `kids_ticket`, `above12_ticket`, `water_infant_ticket`, `water_kids_ticket`, `water_above12_ticket`, `total_price`, `waterticket`, `order_id`, `payment_status`, `payment_id`, `name`, `email`, `number`, `Infant_ticket_price`, `kids_ticket_price`, `above12_ticket_price`, `water_infant_ticket_price`, `water_kids_ticket_price`, `water_above12_ticket_price`) VALUES
(22, 'Pratap Gourav Kendra Ticket', '2023-09-13', 'Indian', 0, 6, 0, 0, 0, 0, '660', 'NO', 'order_MYWPg10PLBSMjI', 'successful', 'pay_MYWPyvdotmWgI2', 'aasdfghj', 'sd@gmail.com', '1234567890', 0, 0, 0, 0, 0, 0),
(23, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 3, 0, 0, 0, 0, '330', 'NO', 'order_MYvvrNNmFpYYBB', 'successful', 'pay_MYvwMRkwVLHHrO', 'Ateeb Haque', 'ateebhaque1912@gmail.com', '9024196730', 0, 0, 0, 0, 0, 0),
(24, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 0, 6, 0, 6, 0, '1260', 'Yes', 'order_Mdi6eiyTSOnH4A', 'successful', 'pay_Mdi6tDQe4EAAmt', 'ateeb', 'ateebhaque1912@gmail.com', '8279291582', 0, 0, 0, 0, 0, 0),
(25, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 1, 6, 0, 6, 0, '1070', 'NO', 'order_MdktQbXrPmEQXs', 'successful', 'pay_MdktaTwaJC4TEH', 'ateeb', 'ateebhaque1912@gmail.com', '8279291582', 0, 0, 0, 0, 0, 0),
(27, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 2, 1, 0, 1, 1, '530', 'Yes', 'order_MdlcPgvnGczTgE', 'successful', 'pay_Mdlcetpx9xFruN', 'ateeb', 'ateeb.muskowl@gmail.com', '1234567890', 0, 0, 0, 0, 0, 0),
(28, 'Pratap Gourav Kendra Ticket', '2023-09-18', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_Mdletw7I8wauD9', 'successful', 'pay_Mdlfb2fLp0ZRYy', 'ateeb', 'ateeb.muskowl@gmail.com', '1234567890', 0, 0, 0, 0, 0, 0),
(29, 'Pratap Gourav Kendra Ticket', '2023-09-18', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MdlmRbJXSdqWKt', 'successful', 'pay_MdlmcvvDbzSib4', 'ateeb', 'ateeb.muskowl@gmail.com', '1234567890', 0, 0, 0, 0, 0, 0),
(30, 'Water laser show', '2023-12-18', 'Indian', 0, 4, 0, 0, 0, 0, '200', 'NO', 'order_Mdloe5mIixFuM2', 'successful', 'pay_MdlpHLF5pfsYJa', 'xyz', 'ateeb.muskowl@gmail.com', '0987654321', 0, 0, 0, 0, 0, 0),
(36, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 7, 0, 0, 0, 0, '770', 'NO', 'order_Me4JkNVAtkOWHN', 'Successful', 'pay_Me4Jsi1C9JVylO', 'Ateeb ', 'hello@gmail.com', '9024196730', 0, 0, 0, 0, 0, 0),
(37, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Foreign', 1, 2, 3, 1, 4, 5, '2600', 'Yes', 'order_Me4iNsMEZn3yl8', 'Successful', 'pay_Me4iY6SGLewIo9', 'know', 'hello@gmail.com', '4532178965', 0, 0, 0, 0, 0, 0),
(38, 'Pratap Gourav Kendra Ticket', '2023-09-19', 'Indian', 0, 2, 3, 0, 0, 9, '1600', 'Yes', 'order_Me4mtVdYhsK34i', 'Successful', 'pay_Me4n5ZASVfcqkG', 'known', 'known@gmail.com', '8765678908', 0, 0, 0, 0, 0, 0),
(39, 'Pratap Gourav Kendra Ticket', '2023-09-30', 'Indian', 0, 7, 0, 0, 0, 0, '770', 'Yes', 'order_Me4sTMibncWMr9', 'Successful', '', 'xyz', 'hello@gmail.com', '9876543218', 0, 0, 0, 0, 0, 0),
(40, 'Water laser show', '2023-09-22', 'Indian', 0, 1, 0, 0, 0, 0, '50', 'NO', 'order_Me4wmtog18uFnd', 'Successful', 'pay_Me4wv9oyA1efIr', 'xyz', 'ateeb.muskowl@gmail.com', '9024196730', 0, 0, 0, 0, 0, 0),
(41, 'Water laser show', '2023-09-23', 'Foreign', 0, 2, 2, 0, 0, 0, '300', 'NO', 'order_Me5Bfekin97ISI', 'Successful', 'pay_Me5Bpje956uzVo', 'xyz', 'ateebhaque1912@gmil.com', '9876567890', 0, 0, 0, 0, 0, 0),
(42, 'Pratap Gourav Kendra Ticket', '2023-09-23', 'Foreign', 0, 2, 2, 0, 6, 0, '1740', 'Yes', 'order_Me5CrGYKqETeTH', 'Successful', 'pay_Me5D0Db1QYtFTa', 'xyz', 'ateebhaque1912@gmil.com', '9876567890', 0, 0, 0, 0, 0, 0),
(43, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 2, 4, 0, 5, 5, '1610', 'Yes', 'order_Me5HV9v23Ef1le', 'Successful', 'pay_Me5HhUR0Q5qrOe', 'Ateeb ', 'hello@gmail.com', '9876789098', 0, 0, 0, 0, 0, 0),
(44, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 3, 0, 0, 0, 0, '330', 'NO', 'order_Me9bg0v6vT7IRD', 'Successful', 'pay_Me9dKpkfnwYVh3', 'Ateeb Haque', 'ateeb.muskowl@gmail.com', '8279291582', 0, 0, 0, 0, 0, 0),
(45, 'Pratap Gourav Kendra Ticket', '2023-09-30', 'Foreign', 0, 1, 0, 0, 0, 0, '260', 'NO', 'order_MeqluHJnPESYBF', 'Successful', 'pay_MeqmFzXtEiErMk', 'hi', 'hi@gmail.com', '9878998765', 0, 0, 0, 0, 0, 0),
(46, 'Pratap Gourav Kendra Ticket', '2023-09-30', 'Indian', 6, 3, 2, 1, 4, 5, '1350', 'Yes', 'order_MerbqLQzyFdJDv', 'Successful', 'pay_Merbycxm1WRRre', 'hi', 'hi@gmail.com', '9878998765', 0, 0, 0, 0, 0, 0),
(49, 'Water laser show', '2023-09-22', 'Indian', 0, 5, 0, 0, 0, 0, '250', 'NO', 'order_MerxMEAX3dzgl8', 'Successful', 'pay_MerxV4R7P7sgS6', 'hi', 'hi@gmail.com', '8789098789', 0, 0, 0, 0, 0, 0),
(50, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 1, 0, 0, 6, 0, '410', 'Yes', 'order_Mest8iySNrEDOf', 'Successful', 'pay_MestJW2S3QJxfl', 'hi', 'hi@gmail.com', '7656789098', 0, 0, 0, 0, 0, 0),
(51, 'Pratap Gourav Kendra Ticket', '2023-09-23', 'Indian', 4, 4, 4, 5, 5, 5, '1830', 'Yes', 'order_MeszHUTcQJUVsS', 'Successful', 'pay_MeszSe3noXKNrK', 'hi', 'hi@gmail.com', '7656787656', 0, 0, 0, 0, 0, 0),
(52, 'Water laser show', '2023-09-30', 'Foreign', 9, 9, 9, 6, 6, 6, '1350', 'Yes', 'order_Met0sqIgPJnWPV', 'Successful', 'pay_Met12UQUxmKfjm', 'hi', 'hi@gmail.com', '2345654345', 0, 0, 0, 0, 0, 0),
(53, 'Water laser show', '2023-09-23', 'Indian', 5, 5, 5, 2, 2, 2, '750', 'Yes', 'order_Met6RlLsviFt2z', 'Successful', 'pay_Met6akWnybhyYw', 'hi', 'hi@gmail.com', '3234567876', 0, 0, 0, 0, 0, 0),
(54, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 1, 1, 1, 5, 5, 5, '150', 'NO', 'order_MetBeYKRY2jfOl', 'Successful', 'pay_MetCJrIib4I5p0', 'hi', 'hi@gmail.com', '1234567890', 0, 0, 0, 0, 0, 0),
(55, 'Water laser show', '2023-09-22', 'Indian', 1, 1, 1, 0, 0, 0, '150', 'NO', 'order_MetHp9g3JAO54r', 'Successful', 'pay_MetIPXFOprTND1', 'hello', 'hello@gmail.com', '5656565656', 0, 0, 0, 0, 0, 0),
(56, 'Water laser show', '2023-09-22', 'Indian', 0, 0, 0, 0, 0, 0, '500', 'Yes', 'order_MetVoCCXaBfxyn', 'Successful', 'pay_MetW0oIVfi1yWy', 'hello', 'hello@gmail.com', '1234567890', 0, 0, 0, 0, 0, 0),
(57, 'Water laser show', '2023-09-22', 'Foreign', 0, 0, 0, 3, 3, 3, '450', 'Yes', 'order_MetgnAiOfy24UX', 'Successful', 'pay_MethCGXLQNTmFx', 'hi', 'hi@gmail.com', '3245676543', 0, 0, 0, 0, 0, 0),
(82, 'Pratap Gourav Kendra Ticket', '2023-09-27', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKQ9O4Nvvr0Xk', '', '', 'hi', 'hello@gmail.com', '1233445566', 0, 0, 0, 0, 0, 0),
(83, 'Pratap Gourav Kendra Ticket', '2023-09-27', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKU4flltOvh8p', '', '', 'hi', 'hello@gmail.com', '1233445566', 0, 0, 0, 0, 0, 0),
(84, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKUWpDnwCTf1o', '', '', 'hi', 'hi@gmail.com', '2334455667', 0, 0, 0, 0, 0, 0),
(85, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKW5ScX20f10N', '', '', 'hi', 'hi@gmail.com', '2334455667', 0, 0, 0, 0, 0, 0),
(86, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKXLKm3uo42eW', '', '', 'hi', 'hi@gmail.com', '2334455667', 0, 0, 0, 0, 0, 0),
(87, 'Pratap Gourav Kendra Ticket', '2023-09-29', 'Indian', 1, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKYBkcYYsfoN9', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(88, 'Pratap Gourav Kendra Ticket', '2023-09-29', 'Indian', 1, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKYpNUZ2r9E0L', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(89, 'Pratap Gourav Kendra Ticket', '2023-09-29', 'Indian', 0, 2, 0, 0, 0, 0, '220', 'NO', 'order_MhKfCTfBmrKwZ9', '', '', 'hi', 'hi@gmail.com', '3232323232', 0, 0, 0, 0, 0, 0),
(90, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKnMKau26gfHN', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(91, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKqfi0Ti01v9v', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(92, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKrHEGJ9GAXHp', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(93, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKsHKhKkM1dOp', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(94, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKsnOcpTluFBP', '', '', 'hi', 'hi@gmail.com', '3535', 10, 0, 0, 0, 0, 0),
(95, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKtFHKtfDMW0l', '', '', 'hi', 'hi@gmail.com', '3535', 10, 0, 0, 0, 0, 0),
(96, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhKtL3KN9jK9pW', '', '', 'hi', 'hi@gmail.com', '3535', 10, 0, 0, 0, 0, 0),
(97, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 2, 0, 0, 0, 0, '220', 'NO', 'order_MhKxaU18EmckUW', '', '', 'hi', 'hi@gmail.com', '3434343434', 0, 0, 0, 0, 0, 0),
(98, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MhLXhjf3SJNPzu', '', '', 'hi', 'hello@gmail.com', '3434343434', 0, 110, 160, 0, 50, 100),
(99, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Foreign', 0, 1, 0, 0, 0, 0, '260', 'NO', 'order_MhLYKT8mUdIRZh', '', '', 'hi', 'hello@gmail.com', '3434343434', 0, 260, 460, 0, 50, 100),
(100, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Foreign', 0, 1, 0, 0, 0, 0, '260', 'NO', 'order_MhLZSi0bWI9KD8', '', '', 'hi', 'hello@gmail.com', '3434343434', 0, 260, 460, 0, 50, 100),
(102, 'Pratap Gourav Kendra Ticket', '2023-09-29', 'Indian', 1, 2, 3, 4, 5, 6, '1550', 'Yes', 'order_MhLkqnNzmG3inc', 'Successful', 'pay_MhLl21ZCY0H3KU', 'hi', 'hello@gmail.com', '1212121212', 0, 110, 160, 0, 50, 100),
(103, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Foreign', 1, 2, 3, 4, 5, 6, '2750', 'Yes', 'order_MhLm9k3KfsLwiU', 'Successful', 'pay_MhLmI2anwF2jMe', 'hello', 'hi@gmail.com', '3434343434', 0, 260, 460, 0, 50, 100),
(104, 'Water laser show', '2023-09-29', 'Indian', 0, 0, 0, 1, 2, 3, '400', 'NO', 'order_MhLq8YJbb9Jn4W', 'Successful', 'pay_MhLqKFNsIBFgkm', 'hi', 'hi@gmail.com', '2323434354', 0, 110, 160, 0, 50, 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_details`
--
ALTER TABLE `booking_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_details`
--
ALTER TABLE `booking_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
