const currentDate = new Date();
const datePicker = document.getElementById("date");
datePicker.min = currentDate.toISOString().split("T")[0];

const india= document.getElementById("btnradio1")
const foreign= document.getElementById("btnradio2")

const P_G_K= document.getElementById("P_ticket")
const water= document.getElementById("water_show")
const ticket_div = document.getElementById("tick")
const water_ticket_N = document.getElementById("water_ticket_N")
const water_ticket_Y = document.getElementById("water_ticket_Y")
const waterticketshow = document.getElementById("waterticketshow")

const time = document.getElementById("Time")
const spanC= document.getElementById("Infant_ticket_price")
const spanY= document.getElementById("kids_ticket_price")
const spanA= document.getElementById("above12_ticket_price")

const spanC_w= document.getElementById("water_infant_ticket_price").textContent;
const spanY_w= document.getElementById("water_kids_ticket_price").textContent;
const spanA_w= document.getElementById("water_above12_ticket_price").textContent;

const water_C_Price = document.getElementById("water_C_Price")
const water_Y_Price = document.getElementById("water_Y_Price")  
const water_A_Price = document.getElementById("water_A_Price")


const C_Price = document.getElementById("C_Price")
const Y_Price = document.getElementById("Y_Price")
const A_Price = document.getElementById("A_Price")
const total = document.getElementById("Total_price")
// const inputprice = document.getElementById("input_price")
const input_I = document.getElementById("Infant_price");
const input_K = document.getElementById("Kids_price");
const input_A = document.getElementById("above12_price");
const input_I_W = document.getElementById("water_Infant_price");
const input_K_W = document.getElementById("water_kides_price");
const input_A_W = document.getElementById("water_above12_price");

document.getElementById("btnradio1").checked = true

foreign.addEventListener("click", F_function)
india.addEventListener("click", I_function)
water.addEventListener("click",W_function)
P_G_K.addEventListener("click",P_G_K_function)

function F_function(){
    spanC.textContent = "0"
    spanY.textContent = "260"
    spanA.textContent = "460"
    input_I.value = "0"
    input_K.value = "260"
    input_A.value = "460"
}

function I_function(){
    spanC.textContent = "0"
    spanY.textContent = "110"
    spanA.textContent = "160"
    input_I.value = "0"
    input_K.value = "110"
    input_A.value = "160"
}

function P_G_K_function(){

    I_function();
    document.getElementById("btnradio1").checked = true
    foreign.addEventListener("click", F_function)
    india.addEventListener("click", I_function)
    time.textContent = "From: 9 am - 6 pm"

}

function W_function(){
    spanC.textContent = spanC_w
    spanY.textContent = spanY_w
    spanA.textContent = spanA_w
    time.textContent = "Start From 7pm"
    foreign.removeEventListener("click", F_function)
    india.removeEventListener("click", I_function)
}

window.addEventListener("change", calculateSum)


function calculateSum() {
    console.log(input_I.value, input_K.value, input_A.value, input_I_W.value, input_K_W.value, input_A_W.value);

    const value1 = parseInt(C_Price.value);
    const value2 = parseInt(Y_Price.value);
    const value3 = parseInt(A_Price.value);
    let sum =0

    if(document.getElementById("btnradio2").checked == true){
        const val1 = value1*0;
        const val2 = value2*260;
        const val3 = value3*460;
         sum = val1 + val2 + val3 ;

        total.textContent = sum;

    }
    if(document.getElementById("btnradio1").checked == true){
    const val1 = value1*0;
    const val2 = value2*110;
    const val3 = value3*160;
     sum = val1 + val2 + val3 ;

    total.textContent = sum;
    }
    if(document.getElementById("water_ticket_N").checked == true){
        waterticketshow.style.display = "none";
    }
    if(document.getElementById("water_ticket_Y").checked == true){
        waterticketshow.style.display = "block";

    }
    if(document.getElementById("water_show").checked == true ){

        ticket_div.style.display = "none";
        waterticketshow.style.display = "none";

        const val1 = value1*0;
        const val2 = value2*50;
        const val3 = value3*100;
         sum = val1 + val2 + val3 ;
    
        total.textContent = sum;

        water_C_Price.value = "0";
        water_Y_Price.value = "0";
        water_A_Price.value = "0";
    }
    if(document.getElementById("P_ticket").checked == true){
        ticket_div.style.display = "block";

    }
    if(document.getElementById("P_ticket").checked == true && document.getElementById("water_ticket_Y").checked == true ){
        // const water_C_Price = document.getElementById("water_C_Price")
        // const water_Y_Price = document.getElementById("water_Y_Price")
        // const water_A_Price = document.getElementById("water_A_Price")
        const value4 = parseInt(water_C_Price.value)
        const value5 = parseInt(water_Y_Price.value)
        const value6 = parseInt(water_A_Price.value)

        const val4 = value4*0;
        const val5 = value5*50;
        const val6 = value6*100;
        const watershow = val4 + val5 + val6;
        sum = sum + watershow;
        total.textContent = sum;
    }
}
