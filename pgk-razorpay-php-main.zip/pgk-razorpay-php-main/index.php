<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maharana Pratap Gorurav Kendra Ticket booking Page</title>
  <link rel="stylesheet" href="style.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');   
    body{
      font-family: 'Open Sans', sans-serif !important;
    }
    .vertical-line{
      border-left: 4px solid #FF9933;
      height: 30px;
      margin-top: 1rem;
      margin-left: 15px;
      margin-right: 15px;
      padding-left: 15px;
    }
    .btn-check:checked+.btn, .btn.active, .btn.show, .btn:first-child:active, :not(.btn-check)+.btn:active {
      color: white !important;
      background-color: #FF9933 !important;
      border-color: #FF9933 !important;
    }
    .btn1{
      border-color: #fff!important;
      color: #fff!important;
      border-radius: 0px !important;
    }
    .btn2{
      border-color: #FF9933!important;
      color: #FF9933!important;
      border-radius: 0px !important;
    }

    .btn1:hover,.btn2:hover{
      color: white !important;
      background-color: #FF9933 !important;
      border-color: #FF9933 !important;
    }
    .font125{
      font-size: 1.25rem !important;
    }
    .font1{
      font-size: 1.15rem !important;
    }
    .font25{
      font-size: 0.825rem !important;
      font-weight: 500;
    }
    .font65{
      font-size: 0.85rem !important;
    }
    .color{
      color: #fff;
      text-decoration: none;
      font-size: 1rem!important;
    }
    .carousel{
      width: 100%!important;
    }
    li{
      font-size: 0.800rem;
      color: gray;
    }
  </style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body >
<!-- Header -->
  <div class="container-fluid" style="background: linear-gradient(131deg, #fb9224,#ff9933, #ed3439);">
    <div class="row">
      <div class="col-md-3  m-1">
        <img src="https://pgk.muskecards.com/wp-content/uploads/2023/06/pgk-logo-website-new.png" height="100px" alt="Home">
      </div>
      <div class="col-md-6 p-0">
          <div class="row">
          <div class="col-md-4 ms-5 mt-3">
            <svg xmlns="http://www.w3.org/2000/svg" height="20" fill="#fff" class="bi bi-telephone-fill" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
            </svg>
            <span class="color">092141 84594</span>
            </div>
          </div>
          <div class="row">
          <div class="col-md-5 mt-3 ms-5">
              <a href="mailto:contact@example.com" class="color">
                <svg xmlns="http://www.w3.org/2000/svg" height="20" fill="#fff " class="bi bi-envelope-fill" viewBox="0 0 16 16">
                  <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/>
                </svg>
                <span class="color">info@pratapgauravkendra.org</span>
              </a>
          </div>
          </div>
      </div>
      <div class="col-md-2 mt-4 pt-3">
        <a class="btn btn-outline-success btn1" href="https://pgk.muskecards.com/" role="button"><b> Go To Website</b></a>
      </div>
    </div>
  </div>


  
  <div class="container-fluid text-dark " >
    <div class="row">

      <div class="col-md-8 mt-4 pe-4" style="font-size: 1.25rem;">
        <h1>Maharana Pratap Gorurav Kendra</h1>
        <span class="ms-2 me-5" style="font-size: 1rem; color: gray;" >Veer Shiromani Maharana Pratap Samiti</span>
        <!-- <div class="col-md-9 mt-3"> -->
          <span>
          <svg xmlns="http://www.w3.org/2000/svg"  height="12" fill="black" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
            <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
          </svg>
        </span>
          <span class="" style="font-size: 0.8rem; color: gray;" >Tiger Hills, Manoharpura, Near Badgoan, Udaipur</span>
      <!-- </div> -->
        
      <div class="row">
            <div class="col-md-6 mt-4 ">
                <p class="ms-2" style="text-align: justify; font-size: 0.800rem; color: gray;">मेवाड के महाराणा प्रताप के शौर्य पराक्रम का यशोगान मेवाड ही नही वरन सम्पूर्ण देश-विदेश तक पहुंचे,इसके लिए कोई सार्थक पहल की जाए।उन्होने यह प्रस्ताव संघ के वरिष्ठ अधिकारियो के समक्ष रखा जिसके फलस्वरूप उदयपुर मे वीर शिरोमणि महाराणा प्रताप समिति का गठन किया गया।प्रारंभ मे इतिहासविदो के साथ चर्चा कर महाराणा प्रताप के जीवन,इतिहास की सटिक जानकारी एवं हल्दीघाटी युद्ध मे महाराणा प्रताप की विजयी हुए जैसे विषय को इंगित करते हुए एक केन्द्र खडा करने का निर्णय किया गया जिसके परिणामस्वरूप प्रताप गौरव केंद्र बनना तय हुआ।प्रारंभ काल मे संघ के स्वयंसेवको के प्रयत्न से राजस्थान मे निधि संग्रह अभियान चलाकर राशि संग्रहण का कार्य प्रारंभ किया गया।शनैः शनैः समाज का सहयोग मिलता गया।18 अगस्त 2008 को शिलान्यास किया गया तत्पश्चात प्रताप गौरव केंद्र के निर्माण को गति मिलती गई और आज यह राष्ट्रीय तीर्थ के रूप मे हमारे समक्ष खडा है।</p>
            </div>
            <div class="col-md-6 mt-4 ">
                <div id="carouselExampleIndicators" class="carousel slide " data-bs-ride="carousel">
                    <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://pgk.muskecards.com/wp-content/uploads/2023/08/2.jpg" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item ">
                        <img src="https://pgk.muskecards.com/wp-content/uploads/2023/08/1.jpg" class="d-block w-100" alt="...">
                    </div>
                  
                    <div class="carousel-item">
                        <img src="https://pgk.muskecards.com/wp-content/uploads/2023/08/4.jpg" class="d-block w-100" alt="...">
                    </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div><br>
        <ol>
          <li><b>Pratap Gaurav Kendra Rashtriya Tirth</b> will open Everyday for Audience. </li>
          <li> Ticket window will be opened for audience at <b>9.30 am to 6.pm</b></li>
          <li>Duration of all <b>exhibition and robotic show</b> visit in Pratap Gaurav Kendra approx one and half hours.</li>
          <li>To maintain Pratap Gaurav Kendra <b>Ticket Per Person above 12 years is 160/- only for General Show and with family 0-5 year child is free and 110/- Ticket for 6-12 year child. Major Attraction Live Water Laser Show, Ticket Per Person above 12 years is 100/- only for General Show and with family 0-5 year child is free and 50/- Ticket for 6-12 year child</b></li>
          <li>For foreign tourist per person ticket <b>above 12 year is 460 /- and 260/- for 6-12 year child and 0-5 year child free.</b> (All shows and headphone are included.)</li>

          <li><b>Smoking and Alcohol </b>consumption within the parking and campus is strictly prohibited. Carrying alcohol and banned substances in vehicles is strictly prohibited within the parking and campus.</li>
          <li>Please <b>switch off the mobile phone</b> and cameras in Pratap Gaurav Kendra.</li>
          <li><b>HUMBLE REQUEST</b> – Your visit to Pratap Gaurav Kendra Rashtriya Tirtha is a pilgrimage to a sacred centre of Bharat’s Cultural traditions and values. We request your support to maintain the peace, dignity and divinity of the complex.</li>
          <li>The management reserves all rights to entry. We apologize for any inconvenience.</li>
          </ol>
      </div>

<!-- Images -->
      

      <!-- Form -->
        <div class="col-md-4 mt-5 " style="background-color: #fff;padding-left:30px;padding-right:0px;border: 1px solid #f7a13a;">
            <div class="row">
              <div class="col-md-12">
            <div class="col-md-20 vertical-line">
                <h3 class="font125">Booking Tour</h3>
            </div>
          </div>
          <div class="border-bottom mt-1"></div>
        </div>
        <form action="pay.php" method="post">
          <div class="row">
            <div class="col-12 mt-1 ms-auto me-auto" >
              <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                <input type="radio" class="btn-check" name="options" id="P_ticket" value="Pratap Gourav Kendra Ticket" autocomplete="off" required checked>
                <label class="btn btn-outline-warning me-2 pb-2" style="color:#706f6f; border-color: #706f6f;" for="P_ticket"><h5 class="font25">Pratap Gourav Kendra Ticket</h5></label>          
                <input type="radio" class="btn-check" name="options" id="water_show" value="Water laser show" autocomplete="off" required>
                <label class="btn btn-outline-warning"style="color:#706f6f; border-color: #706f6f;" for="water_show"><h5 class="font25">Water laser show</h5></label>
            </div>
            </div>
            <div class="border-bottom mt-1"></div>
          </div>

          <div class="row">
            <div class="col-5 mt-1 ms-2">
              <h4 class="font25">Time:</h4>
            </div>
            <div class="col-md-6 mt-1">
              <h4 class="font25"><span id="Time">From: 9 am - 6 pm</span></h4>
            </div>
            <div class="border-bottom  "></div>
          </div>


        <div class="row mt-1 ">
          <div class="col-md-3 mt-2 ms-2 ">
            <h4 class="font25">Date</h4>
          </div>
          <div class="col-md-7">
            <input type="date" id="date" name="date" class="form-select font25" required>
          </div>
          <div class="border-bottom mt-1"></div>
        </div>
        <div class="row mt-1">
          <div class="col-md-3 mt-1 ms-2 ">
            <h4 class="font25">Type:</h4>
          </div>
          <div class="col-md-8">
            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
              <input type="radio" class="btn-check" name="Indian_foreign" id="btnradio1" value="Indian" autocomplete="off" required checked>
              <label class="btn btn-outline-secondary me-3 p-1 font25" for="btnradio1">Indian</label>
            
              <input type="radio" class="btn-check" name="Indian_foreign" id="btnradio2" value="Foreign" autocomplete="off" required>
              <label class="btn btn-outline-secondary p-1 font25" for="btnradio2">Foreign</label>
          </div>
        </div>
        <div class="border-bottom mt-1 "></div>
        </div>
        <div class="row mt-1">
          <div class="col-md-3 ms-2">
            <h4 class="font25">Tickets:</h4>
          </div>
        </div>
        <div class="row mt-0">
          <div class="col-md-7 ms-4 me-0">
            <label class="text-secondary font65">Infant (0-5 Years) ₹<span id="Infant_ticket_price">0</span>.00</label>
            <input type="text" value="0" name="Infant_price" id="Infant_price" style="display: none;">
          </div>
          <div class="col-md-3">
            <select class="form-select font65" name="Infant_ticket" aria-label="Default select example" id="C_Price">
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> 
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
          </div>
        </div>
        <div class="row mt-1">
          <div class="col-md-7 ms-4 mt-1">
            <lable class="text-secondary font65">Kids (6-12 Years) ₹<span id="kids_ticket_price">110</span>.00 </lable>
            <input type="text" value="110" name="Kids_price" id="Kids_price" style="display: none;">
          </div>
          <div class="col-md-3">
            <select class="form-select font65" name="kids_ticket" aria-label="Default select example" id="Y_Price">
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> 
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
          </div>
        </div>
        <div class="row mt-1">
          <div class="col-md-7 ms-4 mt-1">
            <lable class="text-secondary font65">Above (12+ years) ₹<span id="above12_ticket_price">160</span>.00</lable>
            <input type="text" value="160" name="above12_price" id="above12_price" style="display: none;">
          </div>
          <div class="col-md-3">
            <select class="form-select font65"  name="above12_ticket" aria-label="Default select example" id="A_Price">
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> 
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
          </div>
        </div>
        <div class="border-bottom mt-1 "></div>

     


        <div  id="tick" >
          <div class="row mt-1 " id="ticket_div" >
            <div class="col-md-7 ms-2">
              <h4 class="font25">Want to add Water Show ticket</h4>
            </div>
            <div class="col-md-4 ms-3">
              <input type="radio" class="btn-check" name="waterticket" id="water_ticket_N" value="NO" autocomplete="off" required checked>
              <label class="btn btn-outline-warning pb-0" style="color:#706f6f; border-color: #706f6f;" for="water_ticket_N"><h5 class="font65">NO</h5></label>
            
              <input type="radio" class="btn-check" name="waterticket" id="water_ticket_Y" value="Yes" autocomplete="off" required>
              <label class="btn btn-outline-warning pb-0" style="color:#706f6f; border-color: #706f6f;" for="water_ticket_Y"><h5 class="font65">YES</h5></label>
            </div>
            <div class="border-bottom mt-1 "></div>
          </div>
        </div>
        <div class="row" id="waterticketshow" style="display: none;">
        <div class="row mt-1">
          <div class="col-md-9 ms-2">
            <h4 class="font25">Tickets:</h4>
          </div>
        </div>
        <div class="row mt-1">
          <div class= "col-md-8 ms-4 mt-1">
            <label class="text-secondary font65">Infant (0-5 Years) ₹<span id="water_infant_ticket_price">0</span>.00</label>
            <input type="text" value="0" name="water_Infant_price" id="water_Infant_price" style="display: none;">
          </div>
          <div class="col-md-3">
            <select class="form-select font65" name="water_infant_ticket" aria-label="Default select example" id="water_C_Price">
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> 
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
          </div>
        </div>
        <div class="row mt-1">
          <div class="col-md-8 ms-4 mt-1">
            <lable class="text-secondary font65">Kids (6-12 Years) ₹<span id="water_kids_ticket_price">50</span>.00 </lable>
            <input type="text" value="50" name="water_kides_price" id="water_kides_price" style="display: none;">
          </div>
          <div class="col-md-3">
            <select class="form-select font65" name="water_kids_ticket" aria-label="Default select example" id="water_Y_Price">
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> 
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
          </div>
        </div>
        <div class="row mt-1">
          <div class="col-md-8 ms-4 mt-1">
            <lable class="text-secondary font65">Above (12+ years) ₹<span id="water_above12_ticket_price">100</span>.00</lable>
            <input type="text" value="100" name="water_above12_price" id="water_above12_price" style="display: none;">
          </div>
          <div class="col-md-3">
            <select class="form-select font65" name="water_above12_ticket" aria-label="Default select example" id="water_A_Price">
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> 
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>                          
              <option value="10">10</option>
            </select>
          </div>
        </div>
        <div class="border-bottom mt-1 "></div>
      </div>


        <div class="row">
          <div class="col-7 mt-1 ms-2">
            <h4 class="font25">Total:</h4>
          </div>
          <div class="col-4 mt-1">
            <h4 class="font1" style="color: green;font-weight: 600;">₹ <span id="Total_price">0</span>.00</h4>
            <input type="number" id="input_price" name="total_price" value="0"  style="display: none;">
          </div>
          <div class="border-bottom  "></div>
        </div>

        <div class="row mt-1 ">
          <div class="col-md-3 mt-2 ms-2 ">
            <h4 class="font25">Name</h4>
          </div>
          <div class="col-md-8">
            <input type="text" id="name" name="name" class="form-control font65" style=" border:1px solid #c1b9b9 !important;border-radius:0px;" placeholder="Enter Your Name" required>
          </div>
          <div class="border-bottom mt-1"></div>
        </div>

        <div class="row mt-1 ">
          <div class="col-md-3 mt-2 ms-2 ">
            <h4 class="font25">Email ID</h4>
          </div>
          <div class="col-md-8">
            <input type="email" id="email" name="email" class="form-control font65"  style=" border:1px solid #c1b9b9 !important;border-radius:0px;" placeholder="Enter Your Email" required>
          </div>
          <div class="border-bottom mt-1"></div>
        </div>

        <div class="row mt-1 ">
          <div class="col-md-3 mt-2 ms-2 ">
            <h4 class="font25"> Mobile No.</h4>
          </div>
          <div class="col-md-8">
            <input type="number" id="number" name="number" class="form-control font65" style=" border:1px solid #c1b9b9 !important;border-radius:0px;" placeholder="Enter Your Phone Number" required>
          </div>
          <div class="border-bottom mt-1"></div>
        </div>


        <div class="row" id="change_value">
          <div class="col-12 mt-2 mb-3 ms-auto ">
            <button type="submit" id="button" class="btn btn-outline-danger btn2  col-11 pb-0" ><h3 class="font1">BOOK NOW</h3></button>
          </div>
        </div>
      </form>
      </div>
      </div>
      </div>

  <script src="index.js"></script>
  <script>
    // Get the value from the span element
    window.addEventListener('change',function(){

    var spanValue = document.getElementById("Total_price").textContent;

    // Set the value in the input element with number format
    document.getElementById("input_price").value = parseFloat(spanValue);    

    const button = document.getElementById("button");
    const change_value = document.getElementById("change_value");
    const water_C_Price = document.getElementById("water_C_Price")
    const water_Y_Price = document.getElementById("water_Y_Price")
    const water_A_Price = document.getElementById("water_A_Price")


    const C_Price = document.getElementById("C_Price")
    const Y_Price = document.getElementById("Y_Price")
    const A_Price = document.getElementById("A_Price")

    change_value.addEventListener("click",change)
    function change(){
      if(document.getElementById("water_show").checked == true){
      C_Price.value = "0";
      Y_Price.value = "0";
      A_Price.value = "0";
    }
    }

    button.addEventListener("click",valuechange)
    function valuechange(){
    if(document.getElementById("water_show").checked == true){
      water_C_Price.value = C_Price.value;
      water_Y_Price.value = Y_Price.value;
      water_A_Price.value = A_Price.value;
      }
}
})



</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>