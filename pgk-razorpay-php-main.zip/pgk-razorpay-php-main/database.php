<?php
// Establish a database connection (modify the credentials as needed)
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'razorpay';

$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $options = $_POST['options'];
    $date = $_POST['date'];
    $Indian_foreign = $_POST['Indian_foreign'];
    $Infant_ticket = $_POST['Infant_ticket'];
    $kids_ticket = $_POST['kids_ticket'];
    $above12_ticket = $_POST['above12_ticket'];
    $water_infant_ticket = $_POST['water_infant_ticket'];
    $water_kids_ticket = $_POST['water_kids_ticket'];
    $water_above12_ticket = $_POST['water_above12_ticket'];
    $total_price = $_POST['total_price'];
    $waterticket = $_POST['waterticket'];


    // Insert the form data into the database
    $sql = "INSERT INTO booking_details (options, date, Indian_foreign, Infant_ticket, kids_ticket, above12_ticket, water_infant_ticket, water_kids_ticket, water_above12_ticket, total_price, waterticket)
             VALUES ('$options', '$date', '$Indian_foreign', '$Infant_ticket', '$kids_ticket', '$above12_ticket', '$water_infant_ticket', '$water_kids_ticket', '$water_above12_ticket', '$total_price', '$waterticket')";


    if (mysqli_query($conn, $sql)) {
        echo "Form data inserted successfully!";
    } else {
        echo "Error: " . $sql . mysqli_error($conn);
    }

    mysqli_close($conn);
}

?>
