<?php

require('config.php');
require('razorpay-php/Razorpay.php');
session_start();

// Create the Razorpay Order

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);

//
// We create an razorpay order using orders api
// Docs: https://docs.razorpay.com/docs/orders
//

$price = $_POST['total_price'];
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];

if($price == 0){
    "enter an amount";
}
$orderData = [
    'receipt'         => 3456,
    'amount'          => $price * 100, // 2000 rupees in paise
    'currency'        => 'INR',
    'payment_capture' => 1 // auto capture
];

$razorpayOrder = $api->order->create($orderData);

$razorpayOrderId = $razorpayOrder['id'];

$_SESSION['razorpay_order_id'] = $razorpayOrderId;

$displayAmount = $amount = $orderData['amount'];

if ($displayCurrency !== 'INR')
{
    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => "Pratap Gaurav Kendra",
    "description"       => "Tron Legacy",
    "image"             => "https://pgk.muskecards.com/wp-content/uploads/2023/06/pgk-logo-website-new.png",
    "prefill"           => [
    "name"              => $name,
    "email"             => $email,
    "contact"           => $number,
    ],
    "notes"             => [
    "address"           => "Hello World",
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
];

if ($displayCurrency !== 'INR')
{
    $data['display_currency']  = $displayCurrency;
    $data['display_amount']    = $displayAmount;
}

$json = json_encode($data);

?>

<!--  The entire list of Checkout fields is available at
 https://docs.razorpay.com/docs/checkout-form#checkout-fields -->

 <form action="verify.php" method="POST">
  <script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $data['key']?>"
    data-amount="<?php echo $data['amount']?>"
    data-currency="INR"
    data-name="<?php echo $data['name']?>"
    data-image="<?php echo $data['image']?>"
    data-description="<?php echo $data['description']?>"
    data-prefill.name="<?php echo $data['prefill']['name']?>"
    data-prefill.email="<?php echo $data['prefill']['email']?>"
    data-prefill.contact="<?php echo $data['prefill']['contact']?>"
    data-notes.shopping_order_id="3456"
    data-order_id="<?php echo $data['order_id']?>"
    <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
    <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
  >
  </script>
  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
  <input type="hidden" name="shopping_order_id" value="3456">
</form>

<?php
// Establish a database connection (modify the credentials as needed)
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'razorpay';

$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $options = $_POST['options'];
    $date = $_POST['date'];
    $Indian_foreign = $_POST['Indian_foreign'];
    $Infant_ticket = $_POST['Infant_ticket'];
    $kids_ticket = $_POST['kids_ticket'];
    $above12_ticket = $_POST['above12_ticket'];
    $water_infant_ticket = $_POST['water_infant_ticket'];
    $water_kids_ticket = $_POST['water_kids_ticket'];
    $water_above12_ticket = $_POST['water_above12_ticket'];
    $total_price = $_POST['total_price'];
    $waterticket = $_POST['waterticket'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $span_I = $_POST['Infant_price'];
    $span_K = $_POST['Kids_price'];
    $span_A = $_POST['above12_price'];
    $span_I_W = $_POST['water_Infant_price'];
    $span_K_W = $_POST['water_kides_price'];
    $span_A_W = $_POST['water_above12_price'];



    // Insert the form data into the database
    $sql = "INSERT INTO booking_details (options, date, Indian_foreign, Infant_ticket, kids_ticket, above12_ticket, water_infant_ticket, water_kids_ticket, water_above12_ticket, total_price, waterticket, name, email, number, order_id, Infant_ticket_price, kids_ticket_price, above12_ticket_price, water_infant_ticket_price, water_kids_ticket_price, water_above12_ticket_price)
             VALUES ('$options', '$date', '$Indian_foreign', '$Infant_ticket', '$kids_ticket', '$above12_ticket', '$water_infant_ticket', '$water_kids_ticket', '$water_above12_ticket', '$total_price', '$waterticket', '$name', '$email', '$number', '$razorpayOrderId','$span_I', '$span_K', '$span_A', '$span_I_W', '$span_K_W', '$span_A_W')";


    if (mysqli_query($conn, $sql)) {
        echo "Click the pay button.";
    } else {
        echo "Error: " . $sql . mysqli_error($conn);
    }

    mysqli_close($conn);
}

?>
